import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';

const routes: Routes = [
  {
      path: 'primeNos',
      loadChildren: './prime-nos/prime-nos.module#PrimeNosModule'
  },
  {
      path: 'studentRegistrationForm',
      loadChildren: './student-registration-form/student-registration-form.module#StudentRegistrationFormModule'
  },
  {
      path: 'sudokuGame',
      loadChildren: './sudoku-game/sudoku-game.module#SudokuGameModule'
  },
  {
      path: '',
      redirectTo: '/primeNos',
      pathMatch: 'full'
  },
  {
      path: '**',
      redirectTo: '/primeNos',
      pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
