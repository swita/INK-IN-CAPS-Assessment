import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimeNosComponent } from './prime-nos.component';

describe('PrimeNosComponent', () => {
  let component: PrimeNosComponent;
  let fixture: ComponentFixture<PrimeNosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrimeNosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimeNosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
