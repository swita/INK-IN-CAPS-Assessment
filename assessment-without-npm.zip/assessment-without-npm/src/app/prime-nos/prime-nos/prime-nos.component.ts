import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prime-nos',
  templateUrl: './prime-nos.component.html',
  styleUrls: ['./prime-nos.component.css']
})
export class PrimeNosComponent implements OnInit {

  userInput: string = '';
  inputResult: string = '';

  constructor() { }

  ngOnInit() {
  }

  onCheckBtnClick(): void {
    this.inputResult = '';
    const userInputArray = this.userInput.split(',').map(Number);
    userInputArray.forEach(input => {
     this.checkIfNumberIsPrime(input) ? this.inputResult+=input+' is a prime number. \n' : this.inputResult+=input+' is not a prime number. \n';
    });
  }

  checkIfNumberIsPrime = num => {
    for(let i = 2; i < num; i++)
      if(num % i === 0) return false;
    return num > 1;
  }

}
