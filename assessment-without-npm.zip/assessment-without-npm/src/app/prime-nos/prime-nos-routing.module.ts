import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PrimeNosComponent } from './prime-nos/prime-nos.component';

const routes: Routes = [
  { path: '', component: PrimeNosComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrimeNosRoutingModule { }
