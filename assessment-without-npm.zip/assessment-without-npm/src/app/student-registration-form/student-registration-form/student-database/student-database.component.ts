import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { GridApi, GridOptions } from 'ag-grid-community';
import * as utils from '../student-registration-form.utils'

@Component({
  selector: 'app-student-database',
  templateUrl: './student-database.component.html',
  styleUrls: ['./student-database.component.css']
})
export class StudentDatabaseComponent implements OnInit {

  gridApi: GridApi;
  gridOptions: GridOptions;
  pageSize: number = null;
  selectedRow: utils.StudentDataI;
  columnDefs = [];
  @Input() studentData;
  @Output() onDelete = new EventEmitter<any>();
  @Output() onEdit = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
    this.settingGridOptions();
  }

  //setting the grid options for table configuration.
  settingGridOptions() {
    this.pageSize = 5;
    this.gridOptions = utils.studentDataTableGridOptions;
    this.gridOptions.cacheBlockSize =  this.pageSize;
    this.gridOptions.paginationPageSize =  this.pageSize;
    this.settingColumnDefs();
  }

  //setting the column definitions to identify all the columns in the table.
  settingColumnDefs() {
    this.columnDefs = utils.columnDefs;
  }

  //called whenever the value of drop down of page size is changed.
  onPageSizeChanged() {
    this.gridApi.paginationSetPageSize(Number(this.pageSize));
    this.gridOptions.cacheBlockSize = this.pageSize;
    this.gridApi.setDatasource(this.studentData);
  }

  //called whenever all the data is loaded.
  onGridReady(params) {
    this.gridApi = params.api;
    setTimeout(() => this.gridApi);
  }

  editBtnClicked() {
    this.onEdit.emit(this.selectedRow);
  }

  deleteBtnClicked() {
    this.onDelete.emit(this.selectedRow);
  }

  //called whenever a row is selected by clicking.
  onSelectionChange() {
    this.selectedRow = this.gridApi.getSelectedRows().shift();
  }

  //used for refreshing and setting the row data whenever required.
  refreshData(data) {
    this.studentData = data;
    this.gridApi.setRowData(this.studentData);
  }

}
