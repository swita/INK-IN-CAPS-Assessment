import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { StudentDatabaseComponent } from './student-database/student-database.component';
import * as utils from './student-registration-form.utils';
import * as moment from 'moment';

@Component({
  selector: 'app-student-registration-form',
  templateUrl: './student-registration-form.component.html',
  styleUrls: ['./student-registration-form.component.css']
})
export class StudentRegistrationFormComponent implements OnInit {

  @ViewChild('studentDatabase', { static: true }) studentDatabase: StudentDatabaseComponent;
  registrationForm: FormGroup = utils.getStudentRegistrationFrom();
  courses: string[] = utils.courses;
  imageSrc: string = null;
  studentData:utils.StudentDataI[] = [];

  constructor() { }

  ngOnInit() {
    this.getStudentData();
  }

  //fetching the student data from the local storage.
  getStudentData(): void {
    const retrievedData = localStorage.getItem("studentData");
    if (retrievedData)
      this.studentData = JSON.parse(retrievedData);
  }

  //  will be called on every file change event while uploading. And is used for
  //  setting the imgSrc and uploadImgSrc value of the form.
  onUploadImg(event):void {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageSrc = reader.result as string;
        this.registrationForm.patchValue({ uploadImgSrc: reader.result });
      };
    }
  }

  //will be call as soon as the submit btn is clicked which will wait for the current
  //data to be fetched and will later store the data in the local storage also is used
  //to refresh the rows in the database table.
  async onSubmit():Promise<void> {
    const currentData = await this.fetchCurrentData();
    this.studentData[currentData.fetchedDataIndexFromDb] = currentData.currentStudentData;
    this.studentDatabase.refreshData(this.studentData);
    localStorage["studentData"] = (JSON.stringify(this.studentData));
    this.resettingTheForm();
  }

  //used to modify the current data and will also wait for the function to check if id
  //is already present.
  async fetchCurrentData() :Promise<{currentStudentData: utils.StudentDataI,fetchedDataIndexFromDb: number}>{
    let currentStudentData = this.registrationForm.getRawValue();
    currentStudentData.dateOfBirth = currentStudentData.dob.day + '-' + currentStudentData.dob.month + '-' + currentStudentData.dob.year;
    currentStudentData.submittedOn = moment(new Date()).format('DD-MM-YYYY HH:mm');
    if (!currentStudentData.studentId)
      currentStudentData.studentId = Math.floor(Math.random() * 10);
    return await this.checkIfStudentIdIsAlreadyPresent(currentStudentData);
  }

  //used to check if the Id is already present in the Db if present it will return the index
  //along with the current data.
  checkIfStudentIdIsAlreadyPresent(currentStudentData):{currentStudentData: utils.StudentDataI,fetchedDataIndexFromDb: number} {
    let fetchedDataIndexFromDb = this.studentData.findIndex(data => currentStudentData.studentId === data.studentId);
    fetchedDataIndexFromDb = fetchedDataIndexFromDb >= 0 ? fetchedDataIndexFromDb : this.studentData.length;
    return { currentStudentData, fetchedDataIndexFromDb }
  }

  //used to resetting the form and imageSrc and also to set the default values.
  resettingTheForm(): void {
    this.registrationForm.reset();
    this.imageSrc = null;
    this.registrationForm.patchValue({ gender: 'male', courseApplied: 'A' });
  }

  //called when delete btn is clicked and used to filter out the data and resetting the
  //table rows.
  onDelete(selectedRow): void {
    this.studentData = this.studentData.filter(data => selectedRow.studentId != data.studentId);
    this.studentDatabase.refreshData(this.studentData);
    localStorage["studentData"] = (JSON.stringify(this.studentData));
  }

  //called when edit btn is clicked and used to set the values of the form.
  onEdit(selectedRow): void {
    this.registrationForm.patchValue(selectedRow);
    this.imageSrc = selectedRow.uploadImgSrc;
  }

}
