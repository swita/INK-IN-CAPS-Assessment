import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ValueGetterParams } from 'ag-grid-community';

export const getStudentRegistrationFrom = () => {
  return new FormGroup({
    studentId: new FormControl(null),
    studentName: new FormControl(null, [Validators.required, Validators.pattern('[a-zA-Z\\s]*'), Validators.maxLength(30)]),
    fatherName: new FormControl(null, [Validators.required, Validators.pattern('[a-zA-Z\\s]*'), Validators.maxLength(30)]),
    dob: new FormControl(null, [Validators.required]),
    gender: new FormControl('male', [Validators.required]),
    courseApplied: new FormControl('A', [Validators.required]),
    mobNo: new FormControl(null, [Validators.required, Validators.pattern('[1-9][0-9]{9}')]),
    email: new FormControl(null, [Validators.required, Validators.pattern('(.+)@(.+){2,}\.(.+){2,}')]),
    address: new FormControl(null, [Validators.required]),
    uploadImg: new FormControl(null),
    uploadImgSrc: new FormControl(null),
  })
};

export const courses = ['A', 'B'];

export const columnDefs = [
  { headerName: 'S. No.', valueGetter: (args) => getIndexValue(args), lockPosition: true, width: 80, cellStyle: { whiteSpace: 'normal !important', justifyContent: "flex-start", textOverflow: 'ellipsis' }, },
  { headerName: 'Students Name', field: 'studentName', sortable: true, width: 150 },
  { headerName: 'Fathers Name', field: 'fatherName', sortable: true, width: 150 },
  { headerName: 'DOB', field: 'dateOfBirth', width: 130, sortable: true },
  { headerName: 'Gender', field: 'gender', sortable: false, width: 140 },
  { headerName: 'Course', field: 'courseApplied', sortable: false, width: 110 },
  { headerName: 'Mobile No', field: 'mobNo', width: 130, sortable: false },
  { headerName: 'Submitted On', field: 'submittedOn', width: 150, sortable: false }
];

function getIndexValue(args: ValueGetterParams): any {
  return args.node.rowIndex + 1;
}

export interface StudentDataI {
  address: string,
  courseApplied: string,
  dateOfBirth: string,
  dob: DOBI,
  email: string,
  fatherName: string,
  gender: string,
  mobNo: Number,
  studentId: Number,
  studentName: string,
  submittedOn: string,
  uploadImg: string,
  uploadImgSrc: string,
}

export interface DOBI {
  year: Number, month: Number, day: Number,
}

export const studentDataTableGridOptions = {
  rowHeight: 55,
  headerHeight: 55,
  pagination: true,
  suppressCellSelection: true,
  suppressScrollOnNewData: true,
  rowSelection:'single',
  rowMultiSelectWithClick:true,
}
