import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentRegistrationFormComponent } from './student-registration-form/student-registration-form.component';
import { StudentRegistrationFormRoutingModule } from './student-registration-form-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { StudentDatabaseComponent } from './student-registration-form/student-database/student-database.component';
import { AgGridModule } from 'ag-grid-angular';

@NgModule({
  declarations: [StudentRegistrationFormComponent, StudentDatabaseComponent],
  imports: [
    CommonModule,
    StudentRegistrationFormRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    AgGridModule.withComponents([])
  ]
})
export class StudentRegistrationFormModule { }
