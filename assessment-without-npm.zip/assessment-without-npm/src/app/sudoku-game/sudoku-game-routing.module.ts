import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SudokuGameComponent } from './sudoku-game/sudoku-game.component';

const routes: Routes = [
  { path: '', component: SudokuGameComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SudokuGameRoutingModule { }
