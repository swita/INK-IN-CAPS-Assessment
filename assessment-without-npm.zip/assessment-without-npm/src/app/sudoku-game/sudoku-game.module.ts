import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SudokuGameRoutingModule } from './sudoku-game-routing.module';
import { SudokuGameComponent } from './sudoku-game/sudoku-game.component';
import { FormsModule } from '@angular/forms';
import { CountdownModule, CountdownGlobalConfig } from 'ngx-countdown';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxTimerModule } from 'ngx-timer';
import { GameCompletedComponent } from './sudoku-game/game-completed/game-completed.component';

@NgModule({
  declarations: [SudokuGameComponent, GameCompletedComponent],
  imports: [
    CommonModule,
    SudokuGameRoutingModule,
    FormsModule,
    CountdownModule,
    ReactiveFormsModule,
    NgxTimerModule
  ],
  providers: [
    CountdownGlobalConfig
  ],

})
export class SudokuGameModule { }
