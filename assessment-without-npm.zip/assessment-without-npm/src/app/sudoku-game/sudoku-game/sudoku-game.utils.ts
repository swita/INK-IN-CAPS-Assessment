export const levels = ['Hard', 'Medium', 'Easy'];

export const numberBoard = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9]
]

export const solvedBoard = [
  [2, 8, 6, 7, 4, 1, 9, 3, 5],
  [4, 1, 9, 3, 8, 5, 7, 6, 2],
  [3, 5, 7, 9, 6, 2, 4, 1, 8],

  [7, 4, 1, 5, 2, 9, 3, 8, 6],
  [8, 9, 2, 6, 1, 3, 5, 4, 7],
  [6, 3, 5, 8, 7, 4, 1, 2, 9],

  [5, 6, 8, 4, 3, 7, 2, 6, 1],
  [1, 7, 3, 2, 9, 8, 6, 5, 4],
  [9, 2, 4, 1, 5, 6, 8, 7, 3]
];

export const hardUnsolvedBoard = [
  [null, null, 6, null, null, null, 9, null, null],
  [4, 1, 9, null, null, null, null, 6, 2],
  [3, null, null, null, null, null, null, 1, 8],

  [7, null, 1, null, 2, null, null, null, null],
  [8, null, null, null, null, null, 5, 4, 7],
  [6, null, null, null, null, null, null, null,null],

  [5, null, null, null, null, 7, null, 6,null],
  [1, null, null, 2, null, null, null, 5,null],
  [9, null, null, null, null, null, null, null, 3]
];

export const mediumUnsolvedBoard = [
  [null, 8, null, null, null, 1, null, 3, null],
  [null, 1, null, null, 8, null, 7, 6, 2],
  [3, null, null, 9, 6, null, null, null, 8],

  [7, null, null, 5, null, 9, null, 8, 6],
  [null, 9, 2, 6, null, 3, null, null, 7],
  [null, null, null, null, 7, 4, 1, null, null],

  [5, null, null, 4, null, null, null, null, 1],
  [1, 7, null, null, 9, 8, null, null, 4],
  [9, 2, 4, 1, 5, 6, null, 7, null]
];

export const EasyUnsolvedBoard = [
  [2, 8, null, 7, null, null, 9, null, null],
  [null, null, 9, null, 8, 5, null, null, 2],
  [3, 5, 7, 9, 6, null, 4, null, 8],

  [null, 4, null, null, null, 9, null, 8, 6],
  [8, 9, null, 6, null, 3, null, 4, null],
  [null, 3, null, 8, 7, 4, null, 2, null],

  [5, 6, null, null, null, 7, 2, null, 1],
  [null, 7, null, 2, 9, null, 6, null, null],
  [null, 2, null, 1, 5, null, 8, 7, null]

];
