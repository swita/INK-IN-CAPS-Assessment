import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-game-completed',
  templateUrl: './game-completed.component.html',
  styleUrls: ['./game-completed.component.css']
})
export class GameCompletedComponent implements OnInit {

  @Input() timerObj:any={}
  @Output() newGame = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
  }

  onNewGame(){
    this.newGame.emit();
  }

}
