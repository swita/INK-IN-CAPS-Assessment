import { Component, OnInit } from '@angular/core';
import * as utils from './sudoku-game.utils'
import { CountupTimerService, countUpTimerConfigModel, timerTexts } from 'ngx-timer';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-sudoku-game',
  templateUrl: './sudoku-game.component.html',
  styleUrls: ['./sudoku-game.component.css']
})
export class SudokuGameComponent implements OnInit {

  levels: string[] = utils.levels;
  solvedBoard = utils.solvedBoard;
  levelSelected: string = 'Easy';
  unsolvedBoard: number[][] = utils.EasyUnsolvedBoard.map(arr => arr.slice());
  initialBoard: number[][] = utils.EasyUnsolvedBoard.map(arr => arr.slice());
  previousStateBoard: number[][] = utils.EasyUnsolvedBoard.map(arr => arr.slice());
  selectedRowIndex: number = null;
  selectedColumnIndex: number = null;
  numberBoard: number[][] = utils.numberBoard;
  disableUndoButton: boolean = true;
  disableHintButton: boolean = true;
  disableEraseButton: boolean = true;
  notesBatchValue: string = 'Off';
  notes: string = '';
  countUpConfig = new countUpTimerConfigModel();
  isCompleted: boolean = false;
  timerSubscription: Subscription;
  timerObj: any = {};
  noOfErrorInputs: number = 0;

  constructor(private countupTimerService: CountupTimerService) { }

  ngOnInit() {
    this.settingConfigForCountUpTimer();
    this.countupTimerService.startTimer();
  }

  //setting up configs for the timer.
  settingConfigForCountUpTimer(){
    this.countUpConfig.timerTexts = new timerTexts();
    this.countUpConfig.timerTexts.hourText = ":";
    this.countUpConfig.timerTexts.minuteText = ":";
    this.countUpConfig.timerTexts.secondsText = " ";
  }

  pauseTimer() {
    this.countupTimerService.pauseTimer();
  }

  // used for checking if the board is already completed value to false; restarting the timer
  // setting the board values according to the levels selected also cloning the
  //board for previous state and initial state for further use.
  unsolvedBoardRefresh() {
    this.isCompleted = false;
    this.countupTimerService.stopTimer();
    this.countupTimerService.startTimer();
    if (this.levelSelected === 'Easy')
      this.unsolvedBoard = utils.EasyUnsolvedBoard.map(arr => arr.slice());
    else if (this.levelSelected === 'Medium')
      this.unsolvedBoard = utils.mediumUnsolvedBoard.map(arr => arr.slice());
    else
      this.unsolvedBoard = utils.hardUnsolvedBoard.map(arr => arr.slice());
    this.initialBoard = this.unsolvedBoard.map(arr => arr.slice());
    this.previousStateBoard = this.unsolvedBoard.map(arr => arr.slice());
  }

  //called when any input is clicked  for fetching the current index of row and columns.
  onUnsolvedBoardInputClick(rowIndex, columnIndex) {
    this.selectedRowIndex = rowIndex;
    this.selectedColumnIndex = columnIndex;
    this.disableHintButton = false;
    this.checkForTotalNumberOfErrorInputs();
  }

  //whenever any digit on number board is pressed
  onNumberBoardClick(selectedNumber) {
    this.previousStateBoard = this.unsolvedBoard.map(arr => arr.slice());
    this.unsolvedBoard[this.selectedRowIndex][this.selectedColumnIndex] = selectedNumber;
    this.disableEraseButton = this.disableUndoButton = false;
    this.CheckIfCompletedSuccessfully();
  }

  //check if the game is completed successfully accordingly will set the timer value of check
  //for the error in inputs
  CheckIfCompletedSuccessfully() {
    if (this.unsolvedBoard.join('|') === this.solvedBoard.join('|')) {
      this.countupTimerService.pauseTimer();
      this.getTimerValue();
    }
    else
      this.checkForTotalNumberOfErrorInputs();
  }

  //iterate over the entire table for total count of error inputs
  checkForTotalNumberOfErrorInputs() {
    this.noOfErrorInputs = 0
    for (var i = 0; i < this.unsolvedBoard.length; i++) {
      for (var j = 0; j < this.unsolvedBoard[i].length; j++) {
        if (this.unsolvedBoard[i][j] && this.unsolvedBoard[i][j] != this.solvedBoard[i][j]) {
          this.noOfErrorInputs += 1;
        }
      }
    }
  }

  //fetching the current time of the timer on successful complete of the game.
  getTimerValue = () => {
    this.timerSubscription = this.countupTimerService.getTimerValue().subscribe(res => {
      this.timerObj = Object.assign(res);
      this.isCompleted = true;
    });
  }

  onErase() {
    if (this.unsolvedBoard[this.selectedRowIndex][this.selectedColumnIndex])
      this.unsolvedBoard[this.selectedRowIndex][this.selectedColumnIndex] = null;
  }

  onHint() {
    const resultantValue = this.solvedBoard[this.selectedRowIndex][this.selectedColumnIndex];
    this.unsolvedBoard[this.selectedRowIndex][this.selectedColumnIndex] = resultantValue;
  }

  onUndo() {
    this.unsolvedBoard = this.previousStateBoard.map(arr => arr.slice());
    this.disableUndoButton = true;
  }

  onNotes() {
    this.notesBatchValue = this.notesBatchValue === 'Off' ? 'On' : 'Off'
  }

}
